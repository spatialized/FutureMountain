﻿using UnityEngine;
using UnityEditor;
using System;
using System.IO;
using System.Collections.Generic;

namespace SimpleSQL
{
    public class OptionsEditorWindow : EditorWindow
    {
        static private OptionsEditorWindow _instance;

        static public OptionsEditorWindow Instance
        {
            get
            {
                return _instance;
            }
        }

        static public OptionsEditorWindow ShowEditor()
        {
            if (_instance == null)
            {
                _instance = (OptionsEditorWindow)EditorWindow.GetWindow(typeof(OptionsEditorWindow), true, "SimpleSQL Options");
            }

            _instance.ShowUtility();

            _instance.position = new Rect((Screen.width / 2.0f), (Screen.height / 2.0f) + (POSITION_HEIGHT / 2.0f), POSITION_WIDTH, POSITION_HEIGHT);

            Style.Reset();

            return _instance;
        }


        private const string RESOURCE_ROOT = "SimpleSQL.Resources.";
        private const float POSITION_WIDTH = 510.0f;
        private const float POSITION_HEIGHT = 470.0f;

        private DirectoryInfo _editorDirectoryPath = null;
        private DirectoryInfo _pluginsDirectoryPath = null;
        private string _file;
        private string _newFile;

        private int Platform
        {
            get
            {
                return PlayerPrefs.GetInt("SimpleSQL_Editor_Options_Platform", 1);
            }
            set
            {
                PlayerPrefs.SetInt("SimpleSQL_Editor_Options_Platform", value);
            }
        }

        private bool UseSystemData
        {
            get
            {
                return PlayerPrefs.GetInt("SimpleSQL_Editor_Options_UseSystemData", 0) == 1;
            }
            set
            {
                PlayerPrefs.SetInt("SimpleSQL_Editor_Options_UseSystemData", (value ? 1 : 0));
            }
        }

        void OnEnable()
        {
            Style.Reset();
            Resource.LoadTextures();
        }

        void OnGUI()
        {
            if (this.position.width != POSITION_WIDTH || this.position.height != POSITION_HEIGHT)
            {
                this.position = new Rect(this.position.x, this.position.y, POSITION_WIDTH, POSITION_HEIGHT);
                Repaint();
            }

            Style.Reset();
            Resource.LoadTextures();

            GUILayout.BeginVertical();

            GUILayout.Space(10.0f);

            GUILayout.BeginHorizontal();

            GUILayout.Space(10.0f);

            GUILayout.BeginVertical();

            // Platform Optimization

            GUILayout.Label("Optimize Platform");

            GUILayout.BeginVertical(Style.optionBorderStyle);

            GUILayout.Space(10.0f);

            GUILayout.BeginHorizontal();

            GUILayout.Space(10.0f);

            GUIContent [] platforms = new GUIContent[]
            {
                new GUIContent("", (Platform == 0 ? Resource.platformMacOSiOS_On : Resource.platformMacOSiOS_Off), "Mac OS / iOS"),
                new GUIContent("", (Platform == 1 ? Resource.platformUniversal_On : Resource.platformUniversal_Off), "Windows 32, Mac OS, iOS"),
                new GUIContent("", (Platform == 2 ? Resource.platformx64_On : Resource.platformx64_Off), "Windows 64"),
                new GUIContent("", (Platform == 3 ? Resource.platformAndroid_On : Resource.platformAndroid_Off), "Android")
            };

            int platform = Platform; // = GUILayout.SelectionGrid(Platform, platforms, 3, GUILayout.Width(450.0f), GUILayout.Height(100.0f));

            if (GUILayout.Button(platforms[0], Style.noBorderButtonStyle, GUILayout.Width(platforms[0].image.width), GUILayout.Height(platforms[0].image.height)))
            {
                platform = 0;
            }

            GUILayout.Space(20.0f);
            
            if (GUILayout.Button(platforms[1], Style.noBorderButtonStyle, GUILayout.Width(platforms[1].image.width), GUILayout.Height(platforms[1].image.height)))
            {
                platform = 1;
            }

            GUILayout.Space(20.0f);

            if (GUILayout.Button(platforms[3], Style.noBorderButtonStyle, GUILayout.Width(platforms[3].image.width), GUILayout.Height(platforms[3].image.height)))
            {
                platform = 3;
            }

            GUILayout.Space(20.0f);
            
            if (GUILayout.Button(platforms[2], Style.noBorderButtonStyle, GUILayout.Width(platforms[2].image.width), GUILayout.Height(platforms[2].image.height)))
            {
                platform = 2;
            }
            
            if (platform != Platform)
            {
                Platform = platform;

                FindDirectoryPaths();

                if (_pluginsDirectoryPath != null)
                {
                    _newFile = "SimpleSQL_Runtime.dll";

                    File.Delete(_newFile);

                    switch (platform)
                    {
                        case 0:
                            _file = "SimpleSQL_Runtime_Lite.dll.resource";
                            EditorHelper.CreateFileFromEmbeddedResource(RESOURCE_ROOT + _file, Path.Combine(_pluginsDirectoryPath.FullName, _newFile));

                            _newFile = "libsqlite3.so";
                            EditorHelper.DeleteFile(Path.Combine("Assets/Plugins/Android", _newFile), true, true);
                            break;

                        case 1:
                            _file = "SimpleSQL_Runtime.dll.resource";
                            EditorHelper.CreateFileFromEmbeddedResource(RESOURCE_ROOT + _file, Path.Combine(_pluginsDirectoryPath.FullName, _newFile));

                            _newFile = "libsqlite3.so";
                            EditorHelper.DeleteFile(Path.Combine("Assets/Plugins/Android", _newFile), true, true);
                            break;

                        case 2:
                            _file = "SimpleSQL_Runtime_x64.dll.resource";
                            EditorHelper.CreateFileFromEmbeddedResource(RESOURCE_ROOT + _file, Path.Combine(_pluginsDirectoryPath.FullName, _newFile));

                            _newFile = "libsqlite3.so";
                            EditorHelper.DeleteFile(Path.Combine("Assets/Plugins/Android", _newFile), true, true);
                            break;

                        case 3:
                            _file = "SimpleSQL_Runtime_Lite.dll.resource";
                            EditorHelper.CreateFileFromEmbeddedResource(RESOURCE_ROOT + _file, Path.Combine(_pluginsDirectoryPath.FullName, _newFile));

                            _newFile = "libsqlite3.so";
                            _file = "libsqlite3.so.resource";
                            EditorHelper.CreateFileFromEmbeddedResource(RESOURCE_ROOT + _file, Path.Combine("Assets/Plugins/Android", _newFile));
                            break;
                    }

                    AssetDatabase.Refresh();
                }
            }

            GUILayout.EndHorizontal();

            GUILayout.Space(10.0f);

            GUILayout.BeginHorizontal();

            GUILayout.Space(5.0f);

            GUILayout.Label("Mac OS / iOS\n\nSmallest Package\nNo sqlite3", Style.optionBorderStyle, GUILayout.Width(platforms[0].image.width + 10.0f));
            GUILayout.Space(20.0f);
            GUILayout.Label("Mac / iOS / Win\n\nLarger Package\nIncludes sqlite3", Style.optionBorderStyle, GUILayout.Width(platforms[1].image.width));
            GUILayout.Space(10.0f);
            GUILayout.Label("Android\n\nLarger Package\nIncludes libsqlite3\nNo sqlite3", Style.optionBorderStyle, GUILayout.Width(platforms[3].image.width + 10.0f));
            GUILayout.Space(15.0f);
            GUILayout.Label("Windows 64 bit\n\nLargest Package\nIncludes sqlite3", Style.optionBorderStyle, GUILayout.Width(platforms[2].image.width));

            GUILayout.EndHorizontal();

            GUILayout.Space(20.0f);

            GUILayout.EndVertical();

            GUILayout.Space(20.0f);

            // System.Data

            GUILayout.Label("Optimize Data Libraries");

            GUILayout.BeginVertical(Style.optionBorderStyle);

            GUILayout.Space(10.0f);

            GUILayout.BeginHorizontal();

            GUILayout.Space(10.0f);

            GUIContent[] dataLibraries = new GUIContent[]
            {
                new GUIContent("", (!UseSystemData ? Resource.noSystemData_On : Resource.noSystemData_Off), "Don't use System.Data Library"),
                new GUIContent("", (UseSystemData ? Resource.systemData_On : Resource.systemData_Off), "Use System.Data Library"),
            };

            bool useSystemData = UseSystemData;

            if (GUILayout.Button(dataLibraries[0], Style.noBorderButtonStyle, GUILayout.Width(dataLibraries[0].image.width), GUILayout.Height(dataLibraries[0].image.height)))
            {
                useSystemData = false;
            }

            GUILayout.Space(20.0f);

            if (GUILayout.Button(dataLibraries[1], Style.noBorderButtonStyle, GUILayout.Width(dataLibraries[1].image.width), GUILayout.Height(dataLibraries[1].image.height)))
            {
                useSystemData = true;
            }

            if (useSystemData != UseSystemData)
            {
                bool proceed = true;

                if (!useSystemData)
                {
                    if (!EditorUtility.DisplayDialog("Confirm System.Data Removal", "Be sure you remove all references to System.Data and SimpleSQLManager_WithSystemData from your scripts and gameobjects before continuing. If you do not, Unity will likely crash or give errors when the libraries are removed.\n\nAre you sure you want to continue?", "Yes", "No"))
                    {
                        proceed = false;
                    }
                }
                else
                {
                    EditorUtility.DisplayDialog("Notice", "Please be sure to set your player setting's API Compatibility Level to .NET 2.0 (not subset) for the System.Data library to work properly at runtime.", "OK");
                }

                if (proceed)
                {
                    UseSystemData = useSystemData;

                    FindDirectoryPaths();

                    if (useSystemData)
                    {
                        if (_pluginsDirectoryPath != null)
                        {
                            _file = "System.Data.dll";
                            EditorHelper.CreateFileFromEmbeddedResource(RESOURCE_ROOT + _file + ".resource", Path.Combine(_pluginsDirectoryPath.FullName, _file));

                            _file = "SimpleSQL_SystemData.dll";
                            EditorHelper.CreateFileFromEmbeddedResource(RESOURCE_ROOT + _file + ".resource", Path.Combine(_pluginsDirectoryPath.FullName, _file));

                            _file = "SimpleSQLManager_WithSystemData";
                            EditorHelper.CreateFileFromEmbeddedResource(RESOURCE_ROOT + _file + ".resource", Path.Combine(_pluginsDirectoryPath.FullName, _file + ".cs"));
                        }

                        if (_editorDirectoryPath != null)
                        {
                            _file = "SimpleSQLManagerInspector_WithSystemData";
                            EditorHelper.CreateFileFromEmbeddedResource(RESOURCE_ROOT + _file + ".resource", Path.Combine(_editorDirectoryPath.FullName, _file + ".cs"));
                        }
                    }
                    else
                    {
                        if (_editorDirectoryPath != null)
                        {
                            _file = "SimpleSQLManagerInspector_WithSystemData.cs";
                            File.Delete(Path.Combine(_editorDirectoryPath.FullName, _file));
                        }

                        if (_pluginsDirectoryPath != null)
                        {
                            _file = "SimpleSQLManager_WithSystemData.cs";
                            File.Delete(Path.Combine(_pluginsDirectoryPath.FullName, _file));

                            _file = "SimpleSQL_SystemData.dll";
                            File.Delete(Path.Combine(_pluginsDirectoryPath.FullName, _file));

                            _file = "System.Data.dll";
                            File.Delete(Path.Combine(_pluginsDirectoryPath.FullName, _file));
                        }
                    }

                    AssetDatabase.Refresh();
                }
            }

            GUILayout.EndHorizontal();

            GUILayout.Space(10.0f);

            GUILayout.BeginHorizontal();

            GUILayout.Space(10.0f);

            GUILayout.Label("No System.Data\n\nSmaller Pacakge", Style.optionBorderStyle, GUILayout.Width(dataLibraries[1].image.width));
            GUILayout.Space(20.0f);
            GUILayout.Label("Use System.Data\n\nLarger Package", Style.optionBorderStyle, GUILayout.Width(dataLibraries[0].image.width + 10.0f));

            GUILayout.EndHorizontal();

            GUILayout.EndVertical();

            GUILayout.EndVertical();

            GUILayout.Space(10.0f);

            GUILayout.EndHorizontal();

            GUILayout.Space(10.0f);

            GUILayout.EndVertical();
        }

        private void FindDirectoryPaths()
        {
            DirectoryInfo di = new DirectoryInfo(Application.dataPath);

            FileInfo [] fis;
            
            fis = di.GetFiles("SimpleSQL_Editor.dll", SearchOption.AllDirectories);
            _editorDirectoryPath = null;
            if (fis.Length > 0)
            {
                _editorDirectoryPath = fis[0].Directory;
            }

            fis = di.GetFiles("SimpleSQL_Runtime.dll", SearchOption.AllDirectories);
            _pluginsDirectoryPath = null;
            if (fis.Length > 0)
            {
                _pluginsDirectoryPath = fis[0].Directory;
            }
        }
    }
}
